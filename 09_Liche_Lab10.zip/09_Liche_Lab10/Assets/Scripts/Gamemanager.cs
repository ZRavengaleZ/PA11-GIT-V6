﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour
{
    public static int hit = 0;
    public Text ScoreText;
    public static Gamemanager instance = null;
    // Start is called before the first frame update
    private void Awake()
    {
        instance = this;
    }

    // Update is called once per frame
    public void ScoreUpdate()
    {
        hit++;
        ScoreText.text = "Items recycled: " + hit.ToString();
    }
}